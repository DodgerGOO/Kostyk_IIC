OPERATORS = ['+', '-', '*', '/', '^', '%', '√']

DECIMALS = 2
